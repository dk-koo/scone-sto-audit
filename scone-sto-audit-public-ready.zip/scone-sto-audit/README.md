# SCONE STO Audit — research automation starter

A small, independent Python utility for inspecting **existing SCONE/OpenSim `.sto` outputs**. It verifies table structure, checks time series, reports descriptive kinematic/value metrics within an explicitly defined analysis window, handles multiple conditions, and records SHA-256 input hashes for traceability.

This tool is derived from the problem domain and design principles of the maintainer's **SCONE motion analysis v3.0** and **SCONE Agentic Scientist** research projects. It is a clean, dependency-free subset, **not** a publication of the full private research project.

## What works

- Parse UTF-8 whitespace-delimited `.sto` files with `endheader` and numeric scalar columns
- Reject malformed headers, inconsistent row/column counts, missing channels, nonfinite values, and nonincreasing timestamps
- Compute sampled-point minimum, maximum, range of motion (max–min for an explicitly selected angle column), peak absolute value, and arithmetic sample mean
- Analyze a fixed time window and multiple files, export deterministic JSON with source file SHA-256
- Run tests entirely with the Python standard library

## Quickstart

Requires Python 3.10 or newer. No installation or paid simulator license is required to analyze existing `.sto` files.

```bash
python analyzer.py examples/synthetic.sto --columns hip_flexion_r knee_angle_r --start 0.0 --end 0.2 --output report.json
python -m unittest discover -s tests -v
```

For actual SCONE results, pass the original `.sto` file(s) using the *exact* header column names. Source files stay on your machine; no network requests are made.

## Important scientific limitations

- **No SCONE execution or CMA-ES optimization.** This is an output-analysis utility only.
- `.sto` values are reported **in their source units**. `inDegrees` is recorded, not used to guess units or convert arbitrary channels. Verify whether a selected angle is expressed in radians or degrees before interpreting ROM.
- Statistics are computed at sampled time points only, without boundary interpolation, gait-cycle normalization, filtering, or inferential statistical tests.
- Two outputs are not treated as independent biological participants. This software does not establish physiological validity or research conclusions.
- Endpoints of an analysis window must lie within the recorded time interval; a window without sampled observations fails.
- Do not commit human participant data, unpublished results, third-party models, licensed Hyfydy assets, private file paths, or API tokens.

## Reproducibility

JSON includes the input filename (no absolute path), SHA-256, window, selected source channels, observations and software version. Analyze each scientific condition from a separately identified output. A passing test suite verifies software behavior, **not** validation of a biomechanics hypothesis.

## Maintenance

Issues and pull requests are welcome for new supported STO dialects, unit-policy improvements, time window interpolation, and gait-event detection. See [CONTRIBUTING.md](CONTRIBUTING.md) for reproducible issue reports.

Maintainer: [dk-koo](https://github.com/dk-koo). This is an independent original community utility inspired by research needs with SCONE/OpenSim output data. It is **not part of upstream SCONE** and makes no upstream maintainer claim. Licensed under Apache-2.0 (see [LICENSE](LICENSE)). See [CHANGELOG.md](CHANGELOG.md).
