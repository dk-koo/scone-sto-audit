# Changelog

## 0.1.0 — 2026-10-22

Initial public experimental utility: strict scalar STO parsing, multi-file fixed-window summary, SHA-256 evidence fields, synthetic demo, and standard-library unit tests.

This release does not provide SCONE simulator execution, convergence assessment, biological validation, or production support guarantees.
