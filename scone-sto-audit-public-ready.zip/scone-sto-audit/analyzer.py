"""Fail-closed OpenSim/SCONE STO inspection and bounded descriptive metrics.

This utility analyzes existing STO files. It DOES NOT execute SCONE or optimize.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

VERSION = "0.1.0"


class STOError(ValueError):
    """Invalid or scientifically ambiguous input (no results are emitted)."""


def read_sto(path: Path) -> dict[str, Any]:
    """Read a whitespace-delimited, scalar STO table with an endheader marker."""
    if not path.is_file():
        raise STOError(f"Input not found: {path}")
    raw = path.read_bytes()
    try:
        lines = raw.decode("utf-8-sig").splitlines()
    except UnicodeDecodeError as exc:
        raise STOError("STO must be UTF-8 text") from exc

    header_at = next((i for i, s in enumerate(lines) if s.strip().lower() == "endheader"), None)
    if header_at is None:
        raise STOError("Missing endheader marker")
    metadata: dict[str, str] = {}
    for line in lines[:header_at]:
        item = line.strip()
        if "=" in item:
            key, value = item.split("=", 1)
            metadata[key.strip().lower()] = value.strip()
        elif " " in item:
            key, value = item.split(None, 1)
            if key.lower() in {"nrows", "ncolumns", "datarows", "datacolumns", "indegrees"}:
                metadata[key.lower()] = value.strip()

    remaining = [s.strip() for s in lines[header_at + 1:] if s.strip() and not s.lstrip().startswith("#")]
    if len(remaining) < 2:
        raise STOError("Missing column names or data rows")
    names = remaining[0].split()
    if not names or names[0].lower() != "time" or len(names) != len(set(names)):
        raise STOError("First column must be time and column names must be unique")
    rows: list[list[float]] = []
    previous_time = -math.inf
    for index, line in enumerate(remaining[1:], start=1):
        tokens = line.split()
        if len(tokens) != len(names):
            raise STOError(f"Row {index}: expected {len(names)} values, found {len(tokens)}")
        try:
            nums = [float(x) for x in tokens]
        except ValueError as exc:
            raise STOError(f"Row {index}: nonnumeric field") from exc
        if not all(math.isfinite(v) for v in nums):
            raise STOError(f"Row {index}: NaN or infinity")
        if nums[0] <= previous_time:
            raise STOError(f"Row {index}: time must be strictly increasing")
        previous_time = nums[0]
        rows.append(nums)

    for key, observed in (("nrows", len(rows)), ("datarows", len(rows)),
                          ("ncolumns", len(names)), ("datacolumns", len(names))):
        if key in metadata:
            try:
                expected = int(metadata[key])
            except ValueError as exc:
                raise STOError(f"Invalid {key} metadata") from exc
            if expected != observed:
                raise STOError(f"Header {key}={expected}, observed {observed}")
    return {"columns": names, "rows": rows, "metadata": metadata,
            "sha256": hashlib.sha256(raw).hexdigest()}


def analyze(path: Path, columns: list[str], start: float | None = None,
            end: float | None = None) -> dict[str, Any]:
    if not columns or len(columns) != len(set(columns)):
        raise STOError("Provide at least one distinct column")
    table = read_sto(path)
    names, rows = table["columns"], table["rows"]
    missing = [c for c in columns if c not in names or c == names[0]]
    if missing:
        raise STOError("Missing or invalid value columns: " + ", ".join(missing))
    if (start is not None and not math.isfinite(start)) or (end is not None and not math.isfinite(end)):
        raise STOError("Window bounds must be finite")
    lo = rows[0][0] if start is None else start
    hi = rows[-1][0] if end is None else end
    if lo >= hi or lo < rows[0][0] or hi > rows[-1][0]:
        raise STOError("Requested window must be nonempty and fully covered by the data")
    window = [r for r in rows if lo <= r[0] <= hi]
    if not window:
        raise STOError("Requested window contains no sampled rows")
    metrics: dict[str, dict[str, float]] = {}
    for name in columns:
        idx = names.index(name)
        vals = [r[idx] for r in window]
        low, high = min(vals), max(vals)
        metrics[name] = {"min": low, "max": high, "range": high - low,
                         "peak_absolute": max(abs(v) for v in vals),
                         "mean_sampled": sum(vals) / len(vals)}
    return {"input_file": path.name, "input_sha256": table["sha256"],
            "window_seconds": {"start": lo, "end": hi, "samples": len(window)},
            "inDegrees_header": table["metadata"].get("indegrees", "unspecified"),
            "values_in_source_units": True,
            "note": "Sampled-point descriptive statistics only; not interpolated or gait-cycle normalized.",
            "metrics": metrics}


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Audit SCONE/OpenSim .sto files")
    p.add_argument("files", nargs="+", type=Path, help="Input .sto files")
    p.add_argument("--columns", nargs="+", required=True, help="Exact numeric column names")
    p.add_argument("--start", type=float, default=None, help="Window start (seconds)")
    p.add_argument("--end", type=float, default=None, help="Window end (seconds)")
    p.add_argument("--output", type=Path, default=None, help="Optional JSON report path")
    args = p.parse_args(argv)
    try:
        results = [analyze(path, args.columns, args.start, args.end) for path in args.files]
        report = {"tool": "scone-sto-audit", "version": VERSION,
                  "conditions": len(results), "results": results}
        body = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(body, encoding="utf-8")
        else:
            print(body, end="")
        return 0
    except (STOError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
