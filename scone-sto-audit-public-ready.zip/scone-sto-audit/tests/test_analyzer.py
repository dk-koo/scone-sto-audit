import json
import tempfile
import unittest
from pathlib import Path

from analyzer import STOError, analyze, main, read_sto


GOOD = """sample synthetic\nversion=1\nnRows=3\nnColumns=3\ninDegrees=yes\nendheader\ntime hip_flexion_r knee_angle_r\n0.0 0 10\n0.1 20 30\n0.2 10 -40\n"""


class TestSTO(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "synthetic.sto"
        self.path.write_text(GOOD, encoding="utf-8")

    def test_metrics(self):
        result = analyze(self.path, ["hip_flexion_r", "knee_angle_r"])
        self.assertEqual(result["metrics"]["hip_flexion_r"]["range"], 20)
        self.assertEqual(result["metrics"]["knee_angle_r"]["peak_absolute"], 40)
        self.assertEqual(result["window_seconds"]["samples"], 3)

    def test_window(self):
        result = analyze(self.path, ["knee_angle_r"], 0.1, 0.2)
        self.assertEqual(result["metrics"]["knee_angle_r"]["range"], 70)
        self.assertEqual(result["window_seconds"]["samples"], 2)

    def test_hash_and_units(self):
        result = analyze(self.path, ["hip_flexion_r"])
        self.assertEqual(len(result["input_sha256"]), 64)
        self.assertEqual(result["inDegrees_header"], "yes")

    def test_missing_channel(self):
        with self.assertRaises(STOError):
            analyze(self.path, ["unknown"])

    def test_window_outside_data(self):
        with self.assertRaises(STOError):
            analyze(self.path, ["hip_flexion_r"], 0.0, 0.5)

    def test_duplicate_time(self):
        self.path.write_text(GOOD.replace("0.1 20 30", "0.0 20 30"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_nan(self):
        self.path.write_text(GOOD.replace("0.1 20 30", "0.1 NaN 30"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_wrong_width(self):
        self.path.write_text(GOOD.replace("0.1 20 30", "0.1 20"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_header_row_mismatch(self):
        self.path.write_text(GOOD.replace("nRows=3", "nRows=4"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_missing_endheader(self):
        self.path.write_text(GOOD.replace("endheader", "not_endheader"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_nonmonotonic_time(self):
        self.path.write_text(GOOD.replace("0.2 10 -40", "0.05 10 -40"))
        with self.assertRaises(STOError):
            read_sto(self.path)

    def test_batch_report(self):
        target = Path(self.tmp.name) / "report.json"
        status = main([str(self.path), str(self.path), "--columns", "hip_flexion_r", "--output", str(target)])
        self.assertEqual(status, 0)
        self.assertEqual(json.loads(target.read_text())["conditions"], 2)

    def test_failed_batch_does_not_emit_report(self):
        target = Path(self.tmp.name) / "report.json"
        status = main([str(self.path), str(self.path.with_name("missing.sto")), "--columns", "hip_flexion_r", "--output", str(target)])
        self.assertEqual(status, 2)
        self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main()
