# Contributing

Issues: specify Python version, a **synthetic or redacted** minimal `.sto` example, expected behavior and actual behavior. Do not include private patient data or proprietary models. Provide a failing test for a parser or calculation bug when possible.

Pull requests: run `python -m unittest discover -s tests -v`. Keep core parsing dependency-free; document any changes to output units or window semantics. Maintainers review correctness and reproducibility before merging. All project decisions and scientific interpretations remain human-reviewed.
